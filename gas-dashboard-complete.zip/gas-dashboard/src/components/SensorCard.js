// src/components/SensorCard.js

import React from "react";
import { Activity, AlertTriangle, CheckCircle, XCircle } from "lucide-react";

const STATUS_CONFIG = {
  safe:    { color: "#22c55e", bg: "rgba(34,197,94,0.08)",   border: "rgba(34,197,94,0.2)",   Icon: CheckCircle,    label: "SAFE" },
  warning: { color: "#f59e0b", bg: "rgba(245,158,11,0.08)",  border: "rgba(245,158,11,0.3)",  Icon: AlertTriangle,  label: "WARNING" },
  danger:  { color: "#ef4444", bg: "rgba(239,68,68,0.10)",   border: "rgba(239,68,68,0.45)",  Icon: XCircle,        label: "DANGER" },
};

export default function SensorCard({ room, data }) {
  const cfg = STATUS_CONFIG[data.status] || STATUS_CONFIG.safe;
  const { Icon } = cfg;
  const pct = Math.min(100, (data.ppm / 600) * 100);

  return (
    <div style={{
      background: cfg.bg,
      border: `1px solid ${cfg.border}`,
      borderRadius: 10,
      padding: "12px 14px",
      position: "relative",
      overflow: "hidden",
      animation: data.status === "danger" ? "dangerPulse 1s infinite" : "none",
      transition: "border-color 0.4s, background 0.4s",
    }}>
      {/* Glow blob */}
      <div style={{
        position: "absolute", top: -10, right: -10,
        width: 60, height: 60, borderRadius: "50%",
        background: cfg.color,
        opacity: data.status === "safe" ? 0.04 : 0.10,
        filter: "blur(16px)",
        pointerEvents: "none",
      }} />

      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
        <span style={{ fontSize: 11, color: "#8b92a8", fontFamily: "'Courier New', monospace" }}>
          {data.sensorId}
        </span>
        <Icon size={13} color={cfg.color} />
      </div>

      {/* Room name */}
      <div style={{ fontSize: 12, fontWeight: 700, color: "#c8cdd8", marginBottom: 4, letterSpacing: "0.03em" }}>
        {room}
      </div>

      {/* Gas type */}
      <div style={{ fontSize: 10, color: "#555d72", marginBottom: 8, fontFamily: "'Courier New', monospace" }}>
        {data.gasType} detection
      </div>

      {/* PPM big number */}
      <div style={{ display: "flex", alignItems: "baseline", gap: 4, marginBottom: 8 }}>
        <span style={{
          fontSize: 28, fontWeight: 800, color: cfg.color,
          fontFamily: "'Courier New', monospace",
          fontVariantNumeric: "tabular-nums",
          lineHeight: 1,
        }}>
          {data.ppm}
        </span>
        <span style={{ fontSize: 12, color: "#555d72" }}>ppm</span>
      </div>

      {/* Progress bar */}
      <div style={{ height: 3, background: "rgba(255,255,255,0.06)", borderRadius: 2, overflow: "hidden", marginBottom: 6 }}>
        <div style={{
          height: "100%", width: `${pct}%`,
          background: cfg.color,
          borderRadius: 2,
          transition: "width 0.8s ease, background 0.5s",
        }} />
      </div>

      {/* Status + mini sparkline */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{
          fontSize: 10, fontWeight: 700, color: cfg.color,
          fontFamily: "'Courier New', monospace", letterSpacing: "0.08em"
        }}>
          {cfg.label}
        </span>
        <MiniSparkline history={data.history} color={cfg.color} />
      </div>
    </div>
  );
}

function MiniSparkline({ history, color }) {
  const W = 50, H = 18;
  const max = Math.max(...history, 10);
  const pts = history.map((v, i) => {
    const x = (i / (history.length - 1)) * W;
    const y = H - (v / max) * H;
    return `${x},${y}`;
  }).join(" ");

  return (
    <svg width={W} height={H} style={{ overflow: "visible" }}>
      <polyline
        points={pts}
        fill="none"
        stroke={color}
        strokeWidth={1.2}
        strokeLinejoin="round"
        strokeLinecap="round"
        opacity={0.7}
      />
    </svg>
  );
}
