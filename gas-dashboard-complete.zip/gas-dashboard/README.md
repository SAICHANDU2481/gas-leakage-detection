# Gas Leakage Detection & Alert System

IoT-based real-time gas monitoring for 2 apartments — React dashboard + Node.js backend + ESP32 hardware

---

## Project Structure

```
gas-dashboard/
├── src/                          ← React frontend (dashboard)
│   ├── hooks/
│   │   └── useSensorData.js      ← Socket.IO + simulation fallback
│   ├── components/
│   │   ├── SensorCard.js         ← Per-room gas reading card
│   │   ├── GasHeatmap.js         ← Canvas heatmap + flow arrows
│   │   ├── ValveControl.js       ← Gas valve cut/restore UI
│   │   ├── AlertLog.js           ← Real-time alert feed
│   │   ├── PPMChart.js           ← Live Recharts line graph
│   │   └── FlowCompass.js        ← Gas flow direction compasses
│   ├── App.js                    ← Main layout
│   ├── App.css                   ← Styles
│   └── index.js                  ← Entry point
├── server/                       ← Node.js backend
│   ├── index.js                  ← MQTT + Socket.IO + REST API
│   ├── package.json
│   └── .env.example
├── arduino/
│   └── esp32_sensor.ino          ← ESP32 firmware
├── .github/
│   └── workflows/
│       └── deploy.yml            ← Auto-deploy to GitHub Pages
├── .gitignore
├── package.json
└── README.md
```

---

## Quick Start

```bash
git clone https://github.com/YOUR_USERNAME/gas-leakage-system.git
cd gas-leakage-system
npm install
npm start
# Opens at http://localhost:3000 with live simulation
```

---

## Full Implementation — Step by Step

### PHASE 1: Local Development

```bash
# Run React dashboard
cd gas-dashboard
npm install
npm start

# Run backend server (separate terminal)
cd gas-dashboard/server
npm install
cp .env.example .env
npm start
```

### PHASE 2: MQTT Broker (Raspberry Pi)

```bash
sudo apt install mosquitto mosquitto-clients -y
sudo nano /etc/mosquitto/mosquitto.conf
```

Add to config:
```
listener 1883
listener 9001
protocol websockets
allow_anonymous true
```

```bash
sudo systemctl enable mosquitto
sudo systemctl restart mosquitto

# Test
mosquitto_pub -t "gas/aptA/Kitchen" -m "245"
```

### PHASE 3: Hardware Wiring

```
ESP32 GPIO34 ← MQ-2  (Kitchen)
ESP32 GPIO35 ← MQ-5  (Living Room)
ESP32 GPIO32 ← MQ-9  (Bedroom)
ESP32 GPIO33 ← MQ-135 (Bathroom)
ESP32 GPIO26 → Relay  (Gas valve)
ESP32 GPIO27 → Buzzer
```

Upload `arduino/esp32_sensor.ino` — set WIFI_SSID, WIFI_PASSWORD, MQTT_BROKER, APARTMENT.

### PHASE 4: Connect Dashboard to Server

```bash
echo "REACT_APP_SERVER_URL=http://192.168.1.100:4000" > .env
npm start
```

### PHASE 5: Deploy to GitHub Pages

```bash
npm install --save-dev gh-pages
npm run deploy
```

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, Recharts, Lucide React |
| Realtime | Socket.IO |
| Backend | Node.js, Express |
| IoT Protocol | MQTT (Mosquitto) |
| Hardware | ESP32 + MQ sensors |
