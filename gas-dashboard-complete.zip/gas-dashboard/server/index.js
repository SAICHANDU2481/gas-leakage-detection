// server/index.js
// Gas Leakage Detection — Backend Server
// Handles: MQTT broker connection, REST API, WebSocket push to dashboard

const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const mqtt = require("mqtt");
const cors = require("cors");
require("dotenv").config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" }
});

app.use(cors());
app.use(express.json());

// ─── IN-MEMORY STATE ──────────────────────────────────────────────
// Replace with a real DB (InfluxDB / PostgreSQL) in production
const sensorState = {
  A: {
    Kitchen:      { ppm: 0, status: "safe", gasType: "LPG",     lastUpdated: null },
    "Living Room":{ ppm: 0, status: "safe", gasType: "Methane", lastUpdated: null },
    Bedroom:      { ppm: 0, status: "safe", gasType: "CO",      lastUpdated: null },
    Bathroom:     { ppm: 0, status: "safe", gasType: "Methane", lastUpdated: null },
  },
  B: {
    Kitchen:      { ppm: 0, status: "safe", gasType: "LPG",     lastUpdated: null },
    "Living Room":{ ppm: 0, status: "safe", gasType: "Methane", lastUpdated: null },
    Bedroom:      { ppm: 0, status: "safe", gasType: "CO",      lastUpdated: null },
    Bathroom:     { ppm: 0, status: "safe", gasType: "Methane", lastUpdated: null },
  },
};

const valveState = { A: true, B: true }; // true = open

const alertLog = [];

const THRESHOLDS = { warning: 300, danger: 500 };

// ─── HELPERS ──────────────────────────────────────────────────────
function getStatus(ppm) {
  if (ppm >= THRESHOLDS.danger)  return "danger";
  if (ppm >= THRESHOLDS.warning) return "warning";
  return "safe";
}

function addAlert(type, title, message, apt) {
  const alert = { id: Date.now(), type, title, message, apt, time: new Date() };
  alertLog.unshift(alert);
  if (alertLog.length > 100) alertLog.pop();
  // Push to all connected watchman dashboards via WebSocket
  io.emit("alert", alert);
  console.log(`[ALERT][${type.toUpperCase()}] ${title} — ${message}`);
}

function autoValveCut(apt, room, ppm) {
  if (valveState[apt]) {
    valveState[apt] = false;
    addAlert("critical", `AUTO-CUT: Apt ${apt}`, `${ppm} ppm in ${room}. Valve closed.`, apt);
    // Send MQTT command to hardware relay
    mqttClient.publish(`gas/apt${apt}/valve/command`, "CLOSE");
    io.emit("valve_update", { apt, open: false });
  }
}

// ─── MQTT CONNECTION ──────────────────────────────────────────────
const MQTT_BROKER = process.env.MQTT_BROKER || "mqtt://localhost:1883";
const mqttClient = mqtt.connect(MQTT_BROKER);

mqttClient.on("connect", () => {
  console.log(`[MQTT] Connected to broker: ${MQTT_BROKER}`);
  mqttClient.subscribe("gas/apt+/+");         // sensor readings
  mqttClient.subscribe("gas/apt+/valve/status"); // valve feedback
});

mqttClient.on("message", (topic, payload) => {
  // topic examples:
  //   "gas/aptA/Kitchen"         → sensor reading
  //   "gas/aptB/valve/status"    → valve feedback from hardware
  const parts = topic.split("/");
  const aptRaw = parts[1]; // "aptA" or "aptB"
  const apt    = aptRaw === "aptA" ? "A" : "B";

  if (parts[2] === "valve" && parts[3] === "status") {
    const isOpen = payload.toString() === "OPEN";
    valveState[apt] = isOpen;
    io.emit("valve_update", { apt, open: isOpen });
    return;
  }

  const room = parts[2].replace(/_/g, " "); // "Living_Room" → "Living Room"
  const ppm  = parseInt(payload.toString(), 10);
  if (isNaN(ppm)) return;

  const status    = getStatus(ppm);
  const prevStatus = sensorState[apt][room]?.status;

  // Update state
  sensorState[apt][room] = { ...sensorState[apt][room], ppm, status, lastUpdated: new Date() };

  // Push live reading to dashboard
  io.emit("sensor_reading", { apt, room, ppm, status, time: new Date() });

  // Threshold transitions
  if (status === "danger" && prevStatus !== "danger") {
    autoValveCut(apt, room, ppm);
  } else if (status === "warning" && prevStatus === "safe") {
    addAlert("warning", `Warning: ${room} — Apt ${apt}`, `Gas rising: ${ppm} ppm`, apt);
  } else if (status === "safe" && prevStatus !== "safe") {
    addAlert("resolved", `Resolved: ${room} — Apt ${apt}`, `Level returned to safe: ${ppm} ppm`, apt);
  }

  console.log(`[SENSOR] Apt ${apt} | ${room} | ${ppm} ppm | ${status}`);
});

mqttClient.on("error", (err) => {
  console.error("[MQTT] Error:", err.message);
});

// ─── WEBSOCKET (Dashboard live updates) ───────────────────────────
io.on("connection", (socket) => {
  console.log(`[WS] Watchman connected: ${socket.id}`);

  // Send current snapshot on connect
  socket.emit("snapshot", {
    sensors: sensorState,
    valves:  valveState,
    alerts:  alertLog.slice(0, 30),
  });

  // Handle valve commands from dashboard
  socket.on("valve_command", ({ apt, action }) => {
    if (!["A","B"].includes(apt)) return;
    valveState[apt] = action === "OPEN";
    const cmd = action === "OPEN" ? "OPEN" : "CLOSE";
    mqttClient.publish(`gas/apt${apt}/valve/command`, cmd);
    addAlert(
      action === "OPEN" ? "info" : "warning",
      `Valve ${cmd} — Apt ${apt}`,
      `Manual command by watchman`,
      apt
    );
    io.emit("valve_update", { apt, open: valveState[apt] });
  });

  socket.on("emergency_shutdown", () => {
    ["A","B"].forEach((apt) => {
      valveState[apt] = false;
      mqttClient.publish(`gas/apt${apt}/valve/command`, "CLOSE");
    });
    addAlert("critical", "EMERGENCY SHUTDOWN", "All valves cut by watchman", "ALL");
    io.emit("valve_update", { apt: "A", open: false });
    io.emit("valve_update", { apt: "B", open: false });
  });

  socket.on("disconnect", () => {
    console.log(`[WS] Watchman disconnected: ${socket.id}`);
  });
});

// ─── REST API ENDPOINTS ───────────────────────────────────────────
// GET current sensor state
app.get("/api/sensors", (req, res) => {
  res.json({ success: true, data: sensorState, timestamp: new Date() });
});

// GET current valve state
app.get("/api/valves", (req, res) => {
  res.json({ success: true, data: valveState });
});

// POST manual valve command
app.post("/api/valves/:apt", (req, res) => {
  const { apt }    = req.params;
  const { action } = req.body; // "OPEN" or "CLOSE"
  if (!["A","B"].includes(apt) || !["OPEN","CLOSE"].includes(action)) {
    return res.status(400).json({ success: false, error: "Invalid apt or action" });
  }
  valveState[apt] = action === "OPEN";
  mqttClient.publish(`gas/apt${apt}/valve/command`, action);
  addAlert(
    action === "OPEN" ? "info" : "warning",
    `Valve ${action} — Apt ${apt}`,
    "REST API command",
    apt
  );
  io.emit("valve_update", { apt, open: valveState[apt] });
  res.json({ success: true, apt, open: valveState[apt] });
});

// GET alert log
app.get("/api/alerts", (req, res) => {
  const limit = parseInt(req.query.limit) || 50;
  res.json({ success: true, data: alertLog.slice(0, limit) });
});

// Health check
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    mqtt: mqttClient.connected ? "connected" : "disconnected",
    uptime: process.uptime(),
    timestamp: new Date(),
  });
});

// ─── START SERVER ─────────────────────────────────────────────────
const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`\n🔥 Gas Detection Server running on port ${PORT}`);
  console.log(`   REST API:  http://localhost:${PORT}/api`);
  console.log(`   WebSocket: ws://localhost:${PORT}\n`);
});
