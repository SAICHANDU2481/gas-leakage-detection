// src/App.js

import React, { useState, useEffect } from "react";
import { useSensorData } from "./hooks/useSensorData";
import SensorCard from "./components/SensorCard";
import GasHeatmap from "./components/GasHeatmap";
import ValveControl from "./components/ValveControl";
import AlertLog from "./components/AlertLog";
import PPMChart from "./components/PPMChart";
import FlowCompass from "./components/FlowCompass";
import { Wifi, WifiOff, Clock, ShieldAlert, Activity } from "lucide-react";
import "./App.css";

function useClock() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return time;
}

function StatusDot({ ok }) {
  return (
    <span style={{
      display: "inline-block", width: 7, height: 7, borderRadius: "50%",
      background: ok ? "#22c55e" : "#ef4444",
      boxShadow: ok ? "0 0 6px #22c55e" : "0 0 6px #ef4444",
      animation: ok ? "livePulse 1.5s infinite" : "none",
    }} />
  );
}

export default function App() {
  const { readings, valves, alerts, isConnected, cutValve, restoreValve, cutAllValves, rooms } = useSensorData();
  const now = useClock();

  // Derived state
  const maxA = Math.max(...Object.values(readings.A).map((r) => r.ppm));
  const maxB = Math.max(...Object.values(readings.B).map((r) => r.ppm));
  const overallMax = Math.max(maxA, maxB);
  const sysStatus = overallMax >= 500 ? "CRITICAL" : overallMax >= 300 ? "WARNING" : "NORMAL";
  const sysColor  = overallMax >= 500 ? "#ef4444"  : overallMax >= 300 ? "#f59e0b"  : "#22c55e";
  const openValves = (valves.A ? 1 : 0) + (valves.B ? 1 : 0);
  const criticalAlerts = alerts.filter((a) => a.type === "critical").length;

  return (
    <div className="app">

      {/* ── HEADER ── */}
      <header className="header">
        <div className="header-left">
          <div className="logo">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path d="M12 2C8.5 7 6 10 6 14a6 6 0 0012 0c0-4-2.5-7-6-12z" fill="#ef4444" opacity="0.9"/>
              <path d="M12 8c-1.5 3-2 5-2 7a2 2 0 004 0c0-2-.5-4-2-7z" fill="#fbbf24"/>
            </svg>
          </div>
          <div>
            <h1 className="app-title">Gas Leakage Detection System</h1>
            <div className="app-subtitle">IoT Monitoring · 2 Apartments · 8 Sensors</div>
          </div>
        </div>

        <div className="header-right">
          <div className="header-badge">
            <StatusDot ok={isConnected} />
            <span style={{ color: isConnected ? "#22c55e" : "#ef4444", fontSize: 12 }}>
              {isConnected ? "LIVE" : "OFFLINE"}
            </span>
          </div>
          <div className="header-clock">
            <Clock size={12} />
            {now.toLocaleTimeString("en-IN", { hour12: false })}
          </div>
          <div className="watchman-pill">
            👁 Watchman Active
          </div>
        </div>
      </header>

      {/* ── STATUS BAR ── */}
      <div className="status-bar">
        {[
          { label: "System",      value: sysStatus,           color: sysColor },
          { label: "Apt A Max",   value: `${maxA} ppm`,       color: maxA >= 500 ? "#ef4444" : maxA >= 300 ? "#f59e0b" : "#22c55e" },
          { label: "Apt B Max",   value: `${maxB} ppm`,       color: maxB >= 500 ? "#ef4444" : maxB >= 300 ? "#f59e0b" : "#22c55e" },
          { label: "Valves Open", value: `${openValves}/2`,   color: openValves === 2 ? "#22c55e" : openValves === 0 ? "#ef4444" : "#f59e0b" },
          { label: "Critical",    value: `${criticalAlerts}`, color: criticalAlerts > 0 ? "#ef4444" : "#22c55e" },
          { label: "Sensors",     value: "8 / 8",             color: "#22c55e" },
        ].map(({ label, value, color }, i) => (
          <React.Fragment key={label}>
            {i > 0 && <div className="stat-divider" />}
            <div className="stat">
              <span className="stat-label">{label}</span>
              <span className="stat-value" style={{ color }}>{value}</span>
            </div>
          </React.Fragment>
        ))}
      </div>

      {/* ── EMERGENCY BANNER ── */}
      {sysStatus === "CRITICAL" && (
        <div className="emergency-banner">
          <ShieldAlert size={20} color="#ef4444" style={{ flexShrink: 0 }} />
          <div>
            <div style={{ fontWeight: 700, color: "#ef4444", fontSize: 14 }}>
              CRITICAL GAS LEAK DETECTED
            </div>
            <div style={{ fontSize: 12, color: "#8b92a8" }}>
              Concentration above safe threshold · Auto-cut initiated · Evacuate if necessary
            </div>
          </div>
          <button className="btn-emergency" onClick={cutAllValves}>
            EMERGENCY SHUTDOWN
          </button>
        </div>
      )}

      {/* ── MAIN GRID ── */}
      <main className="main-grid">

        {/* Apt A Sensors */}
        <section className="card">
          <div className="card-header">
            <Activity size={14} color="#14b8a6" />
            <span className="card-title">Sensor Readings</span>
            <span className="apt-tag teal">Apartment A</span>
          </div>
          <div className="sensor-grid">
            {rooms.map((room) => (
              <SensorCard key={room} room={room} data={readings.A[room]} />
            ))}
          </div>
        </section>

        {/* Apt B Sensors */}
        <section className="card">
          <div className="card-header">
            <Activity size={14} color="#8b5cf6" />
            <span className="card-title">Sensor Readings</span>
            <span className="apt-tag purple">Apartment B</span>
          </div>
          <div className="sensor-grid">
            {rooms.map((room) => (
              <SensorCard key={room} room={room} data={readings.B[room]} />
            ))}
          </div>
        </section>

        {/* Heatmap A */}
        <section className="card">
          <div className="card-header">
            <span className="card-title">Gas Heatmap</span>
            <span className="apt-tag teal">Apartment A</span>
          </div>
          <GasHeatmap readings={readings.A} />
        </section>

        {/* Heatmap B */}
        <section className="card">
          <div className="card-header">
            <span className="card-title">Gas Heatmap</span>
            <span className="apt-tag purple">Apartment B</span>
          </div>
          <GasHeatmap readings={readings.B} />
        </section>

        {/* Flow Compass */}
        <section className="card">
          <div className="card-header">
            <span className="card-title">Gas Flow Direction</span>
          </div>
          <FlowCompass readings={readings} rooms={rooms} />
        </section>

        {/* Valve Control */}
        <section className="card">
          <div className="card-header">
            <span className="card-title">Valve Control Panel</span>
          </div>
          <ValveControl
            valves={valves}
            cutValve={cutValve}
            restoreValve={restoreValve}
            cutAllValves={cutAllValves}
            readings={readings}
          />
        </section>

        {/* PPM History Chart */}
        <section className="card">
          <div className="card-header">
            <span className="card-title">PPM History</span>
            <span style={{ fontSize: 11, color: "#555d72", marginLeft: "auto" }}>Last 25 readings</span>
          </div>
          <PPMChart readings={readings} />
        </section>

        {/* Alert Log */}
        <section className="card">
          <div className="card-header">
            <span className="card-title">Alert Log</span>
            <span style={{
              marginLeft: "auto", fontSize: 11, fontWeight: 700,
              color: criticalAlerts > 0 ? "#ef4444" : "#555d72",
              fontFamily: "'Courier New', monospace",
            }}>
              {criticalAlerts > 0 ? `${criticalAlerts} CRITICAL` : `${alerts.length} events`}
            </span>
          </div>
          <AlertLog alerts={alerts} />
        </section>

      </main>
    </div>
  );
}
