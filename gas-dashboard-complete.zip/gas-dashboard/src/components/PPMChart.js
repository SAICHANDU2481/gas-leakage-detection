// src/components/PPMChart.js

import React, { useState, useEffect, useRef } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ReferenceLine, ResponsiveContainer,
} from "recharts";
import { format } from "date-fns";

const MAX_POINTS = 25;
const WARNING = 300;
const DANGER  = 500;

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: "#1e2535", border: "1px solid rgba(255,255,255,0.1)",
      borderRadius: 8, padding: "10px 14px",
    }}>
      <div style={{ fontSize: 11, color: "#555d72", marginBottom: 6 }}>{label}</div>
      {payload.map((p) => (
        <div key={p.name} style={{ fontSize: 12, color: p.color, marginBottom: 2 }}>
          {p.name}: <strong>{p.value} ppm</strong>
        </div>
      ))}
    </div>
  );
}

export default function PPMChart({ readings }) {
  const [history, setHistory] = useState([]);
  const counterRef = useRef(0);

  useEffect(() => {
    const maxA = Math.max(...Object.values(readings.A).map((r) => r.ppm));
    const maxB = Math.max(...Object.values(readings.B).map((r) => r.ppm));
    counterRef.current += 1;

    const point = {
      time: format(new Date(), "HH:mm:ss"),
      "Apt A": maxA,
      "Apt B": maxB,
      idx: counterRef.current,
    };

    setHistory((prev) => {
      const next = [...prev, point];
      return next.length > MAX_POINTS ? next.slice(-MAX_POINTS) : next;
    });
  }, [readings]);

  return (
    <ResponsiveContainer width="100%" height={190}>
      <LineChart data={history} margin={{ top: 6, right: 16, bottom: 0, left: -16 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
        <XAxis
          dataKey="time"
          tick={{ fill: "#555d72", fontSize: 10, fontFamily: "'Courier New', monospace" }}
          tickLine={false}
          axisLine={false}
          interval="preserveStartEnd"
        />
        <YAxis
          domain={[0, 700]}
          tick={{ fill: "#555d72", fontSize: 10, fontFamily: "'Courier New', monospace" }}
          tickLine={false}
          axisLine={false}
        />
        <Tooltip content={<CustomTooltip />} />
        <Legend
          wrapperStyle={{ fontSize: 12, color: "#8b92a8", paddingTop: 4 }}
        />
        <ReferenceLine y={WARNING} stroke="rgba(245,158,11,0.35)" strokeDasharray="4 4" label={{ value: "Warn", fill: "#f59e0b", fontSize: 9 }} />
        <ReferenceLine y={DANGER}  stroke="rgba(239,68,68,0.35)"  strokeDasharray="4 4" label={{ value: "Danger", fill: "#ef4444", fontSize: 9 }} />
        <Line
          type="monotone" dataKey="Apt A" stroke="#14b8a6"
          strokeWidth={2} dot={false} activeDot={{ r: 3 }}
          isAnimationActive={false}
        />
        <Line
          type="monotone" dataKey="Apt B" stroke="#8b5cf6"
          strokeWidth={2} dot={false} activeDot={{ r: 3 }}
          isAnimationActive={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
