// src/components/AlertLog.js

import React from "react";
import { AlertTriangle, Info, XCircle, CheckCircle, Siren } from "lucide-react";
import { format } from "date-fns";

const ALERT_CFG = {
  critical: { color: "#ef4444", bg: "rgba(239,68,68,0.07)", border: "rgba(239,68,68,0.3)", Icon: XCircle },
  warning:  { color: "#f59e0b", bg: "rgba(245,158,11,0.06)", border: "rgba(245,158,11,0.25)", Icon: AlertTriangle },
  info:     { color: "#3b82f6", bg: "rgba(59,130,246,0.06)", border: "rgba(59,130,246,0.2)", Icon: Info },
  resolved: { color: "#22c55e", bg: "rgba(34,197,94,0.05)", border: "rgba(34,197,94,0.2)", Icon: CheckCircle },
};

export default function AlertLog({ alerts }) {
  const criticalCount = alerts.filter((a) => a.type === "critical").length;
  const warningCount  = alerts.filter((a) => a.type === "warning").length;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>

      {/* Summary badges */}
      <div style={{ display: "flex", gap: 8, marginBottom: 4 }}>
        {[
          { label: "Critical", count: criticalCount, color: "#ef4444" },
          { label: "Warnings", count: warningCount, color: "#f59e0b" },
          { label: "Total",    count: alerts.length, color: "#555d72" },
        ].map(({ label, count, color }) => (
          <div key={label} style={{
            background: "#161b26", border: "1px solid rgba(255,255,255,0.07)",
            borderRadius: 6, padding: "4px 10px", fontSize: 11, color,
            fontFamily: "'Courier New', monospace",
          }}>
            <span style={{ fontWeight: 700 }}>{count}</span>
            <span style={{ color: "#555d72", marginLeft: 4 }}>{label}</span>
          </div>
        ))}
      </div>

      {/* Alert list */}
      <div style={{ maxHeight: 300, overflowY: "auto", display: "flex", flexDirection: "column", gap: 6 }}>
        {alerts.length === 0 && (
          <div style={{ textAlign: "center", color: "#555d72", padding: "20px 0", fontSize: 12 }}>
            No alerts — all clear
          </div>
        )}
        {alerts.map((alert) => {
          const cfg = ALERT_CFG[alert.type] || ALERT_CFG.info;
          const { Icon } = cfg;
          return (
            <div
              key={alert.id}
              style={{
                background: cfg.bg,
                border: `1px solid ${cfg.border}`,
                borderLeft: `3px solid ${cfg.color}`,
                borderRadius: 8,
                padding: "9px 12px",
                display: "flex",
                gap: 10,
                alignItems: "flex-start",
              }}
            >
              <Icon size={15} color={cfg.color} style={{ marginTop: 1, flexShrink: 0 }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#d8dce6", marginBottom: 2 }}>
                  {alert.title}
                </div>
                <div style={{ fontSize: 11, color: "#555d72" }}>{alert.message}</div>
              </div>
              <div style={{ flexShrink: 0, textAlign: "right" }}>
                <div style={{ fontSize: 10, color: "#555d72", fontFamily: "'Courier New', monospace" }}>
                  {format(alert.time, "HH:mm:ss")}
                </div>
                {alert.apt !== "SYSTEM" && (
                  <div style={{
                    fontSize: 9, marginTop: 2, padding: "1px 5px", borderRadius: 3,
                    background: "rgba(255,255,255,0.05)", color: "#555d72",
                    fontFamily: "'Courier New', monospace",
                  }}>
                    APT {alert.apt}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
