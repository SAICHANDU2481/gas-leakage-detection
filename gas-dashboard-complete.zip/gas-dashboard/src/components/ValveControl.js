// src/components/ValveControl.js

import React, { useState } from "react";
import { Power, AlertOctagon, RefreshCw, Zap } from "lucide-react";

export default function ValveControl({ valves, cutValve, restoreValve, cutAllValves, readings }) {
  const [confirming, setConfirming] = useState(null);

  const handleToggle = (apt) => {
    if (valves[apt]) {
      setConfirming(apt);
    } else {
      restoreValve(apt);
    }
  };

  const confirmCut = (apt) => {
    cutValve(apt);
    setConfirming(null);
  };

  const getMaxPPM = (apt) =>
    Math.max(...Object.values(readings[apt]).map((r) => r.ppm));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>

      {/* Emergency All-Cut */}
      <div style={{
        background: "rgba(239,68,68,0.07)",
        border: "1px solid rgba(239,68,68,0.25)",
        borderRadius: 10,
        padding: "12px 16px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 12,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <AlertOctagon size={18} color="#ef4444" />
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#ef4444" }}>Emergency Shutdown</div>
            <div style={{ fontSize: 11, color: "#555d72" }}>Cuts gas supply to both apartments immediately</div>
          </div>
        </div>
        <button
          onClick={cutAllValves}
          style={{
            background: "rgba(239,68,68,0.15)",
            border: "1px solid rgba(239,68,68,0.5)",
            color: "#ef4444",
            padding: "7px 14px",
            borderRadius: 7,
            fontSize: 12,
            fontWeight: 700,
            cursor: "pointer",
            fontFamily: "'Courier New', monospace",
            whiteSpace: "nowrap",
          }}
        >
          CUT ALL
        </button>
      </div>

      {/* Per-Apartment Valves */}
      {["A", "B"].map((apt) => {
        const isOpen = valves[apt];
        const maxPPM = getMaxPPM(apt);
        const autoMsg = maxPPM >= 500 ? "Auto-cut: critical level" : null;
        const aptColor = apt === "A" ? "#14b8a6" : "#8b5cf6";

        return (
          <div
            key={apt}
            style={{
              background: "#161b26",
              border: `1px solid ${isOpen ? "rgba(255,255,255,0.08)" : "rgba(239,68,68,0.3)"}`,
              borderRadius: 10,
              padding: 14,
              transition: "border-color 0.4s",
            }}
          >
            {/* Header */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{
                  width: 8, height: 8, borderRadius: "50%",
                  background: isOpen ? "#22c55e" : "#ef4444",
                  boxShadow: `0 0 8px ${isOpen ? "#22c55e" : "#ef4444"}`,
                }} />
                <span style={{ fontSize: 14, fontWeight: 700, color: aptColor }}>
                  Apartment {apt} — Main Valve
                </span>
              </div>
              <span style={{
                fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 4,
                background: isOpen ? "rgba(34,197,94,0.12)" : "rgba(239,68,68,0.12)",
                color: isOpen ? "#22c55e" : "#ef4444",
                fontFamily: "'Courier New', monospace",
              }}>
                {isOpen ? "OPEN" : "CLOSED"}
              </span>
            </div>

            {/* Stats row */}
            <div style={{ display: "flex", gap: 16, marginBottom: 12 }}>
              <div>
                <div style={{ fontSize: 10, color: "#555d72" }}>Max PPM</div>
                <div style={{
                  fontSize: 16, fontWeight: 700,
                  color: maxPPM >= 500 ? "#ef4444" : maxPPM >= 300 ? "#f59e0b" : "#22c55e",
                  fontFamily: "'Courier New', monospace",
                }}>
                  {maxPPM}
                </div>
              </div>
              <div>
                <div style={{ fontSize: 10, color: "#555d72" }}>Rooms</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: "#8b92a8" }}>4</div>
              </div>
              <div>
                <div style={{ fontSize: 10, color: "#555d72" }}>Auto-cut</div>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#f59e0b", display: "flex", alignItems: "center", gap: 4 }}>
                  <Zap size={12} /> Armed
                </div>
              </div>
            </div>

            {/* Auto-cut warning */}
            {autoMsg && (
              <div style={{
                fontSize: 11, color: "#ef4444", marginBottom: 8,
                fontFamily: "'Courier New', monospace",
                display: "flex", alignItems: "center", gap: 4,
              }}>
                ⚡ {autoMsg}
              </div>
            )}

            {/* Confirmation dialog */}
            {confirming === apt ? (
              <div style={{
                background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.3)",
                borderRadius: 7, padding: "10px 12px", marginBottom: 8
              }}>
                <div style={{ fontSize: 12, color: "#ef4444", fontWeight: 600, marginBottom: 8 }}>
                  Confirm cutting gas to Apartment {apt}?
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={() => confirmCut(apt)} style={{
                    flex: 1, background: "rgba(239,68,68,0.2)", border: "1px solid rgba(239,68,68,0.5)",
                    color: "#ef4444", padding: "6px 0", borderRadius: 6, fontSize: 12,
                    fontWeight: 700, cursor: "pointer",
                  }}>Yes, Cut</button>
                  <button onClick={() => setConfirming(null)} style={{
                    flex: 1, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)",
                    color: "#8b92a8", padding: "6px 0", borderRadius: 6, fontSize: 12, cursor: "pointer",
                  }}>Cancel</button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => handleToggle(apt)}
                style={{
                  width: "100%", padding: "8px 0", borderRadius: 7, fontSize: 12,
                  fontWeight: 700, cursor: "pointer",
                  background: isOpen ? "rgba(239,68,68,0.08)" : "rgba(34,197,94,0.08)",
                  border: `1px solid ${isOpen ? "rgba(239,68,68,0.35)" : "rgba(34,197,94,0.35)"}`,
                  color: isOpen ? "#ef4444" : "#22c55e",
                  fontFamily: "'Courier New', monospace",
                  display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                }}
              >
                {isOpen ? (
                  <><Power size={13} /> Cut Gas Supply</>
                ) : (
                  <><RefreshCw size={13} /> Restore Gas Supply</>
                )}
              </button>
            )}
          </div>
        );
      })}
    </div>
  );
}
