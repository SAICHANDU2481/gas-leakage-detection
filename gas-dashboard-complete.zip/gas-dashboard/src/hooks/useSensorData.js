// src/hooks/useSensorData.js
// Connects to the Node.js backend via Socket.IO for real-time updates.
// Falls back to simulation if server is not reachable (for offline demo).

import { useState, useEffect, useRef, useCallback } from "react";

const ROOMS = ["Kitchen", "Living Room", "Bedroom", "Bathroom"];
const THRESHOLDS = { safe: 150, warning: 300, danger: 500 };

// Change this to your server IP when running on a real network
const SERVER_URL = process.env.REACT_APP_SERVER_URL || "http://localhost:4000";

// Simulation baselines (used when server is offline)
const BASELINES = {
  A: { Kitchen: 40, "Living Room": 20, Bedroom: 12, Bathroom: 18 },
  B: { Kitchen: 35, "Living Room": 18, Bedroom: 10, Bathroom: 15 },
};

function simulatePPM(base, tick, key) {
  const drift = Math.sin(tick * 0.08 + key.length) * 15;
  const spike = Math.random() < 0.04 ? Math.random() * 350 + 150 : 0;
  const noise = (Math.random() - 0.5) * 20;
  return Math.max(0, Math.round(base + drift + spike + noise));
}

function getStatus(ppm) {
  if (ppm >= THRESHOLDS.danger)  return "danger";
  if (ppm >= THRESHOLDS.warning) return "warning";
  return "safe";
}

function buildInitialReadings() {
  const result = {};
  ["A", "B"].forEach((apt) => {
    result[apt] = {};
    ROOMS.forEach((room) => {
      const ppm = BASELINES[apt][room];
      result[apt][room] = {
        ppm, status: getStatus(ppm),
        history:     Array(20).fill(ppm),
        gasType:     room === "Kitchen" ? "LPG" : room === "Bedroom" ? "CO" : "Methane",
        sensorId:    `SEN-${apt}-${room.slice(0, 3).toUpperCase()}`,
        lastUpdated: new Date(),
      };
    });
  });
  return result;
}

export function useSensorData() {
  const tickRef       = useRef(0);
  const socketRef     = useRef(null);
  const simulatingRef = useRef(true);
  const simIntervalRef = useRef(null);

  const [readings,    setReadings]    = useState(buildInitialReadings);
  const [valves,      setValves]      = useState({ A: true, B: true });
  const [alerts,      setAlerts]      = useState([
    { id: 1, type: "info", title: "System Online", message: "Dashboard loaded — simulation mode", time: new Date(), apt: "SYSTEM" }
  ]);
  const [isConnected, setIsConnected] = useState(false);

  const addAlert = useCallback((type, title, message, apt) => {
    setAlerts((prev) => [
      { id: Date.now(), type, title, message, time: new Date(), apt },
      ...prev.slice(0, 29),
    ]);
  }, []);

  const updateRoom = useCallback((apt, room, ppm) => {
    const status = getStatus(ppm);
    setReadings((prev) => ({
      ...prev,
      [apt]: {
        ...prev[apt],
        [room]: {
          ...prev[apt][room],
          ppm, status,
          lastUpdated: new Date(),
          history: [...(prev[apt][room]?.history || []).slice(1), ppm],
        },
      },
    }));
  }, []);

  const startSimulation = useCallback(() => {
    simulatingRef.current = true;
    clearInterval(simIntervalRef.current);
    simIntervalRef.current = setInterval(() => {
      tickRef.current += 1;
      const tick = tickRef.current;
      ["A","B"].forEach((apt) => {
        ROOMS.forEach((room) => {
          const ppm = simulatePPM(BASELINES[apt][room], tick, room + apt);
          updateRoom(apt, room, ppm);
        });
      });
    }, 2000);
  }, [updateRoom]);

  useEffect(() => {
    // Start simulation immediately for demo
    startSimulation();

    // Try to connect to real backend server
    let socket;
    const tryConnect = async () => {
      try {
        const { io } = await import("socket.io-client");
        socket = io(SERVER_URL, { timeout: 3000, reconnectionAttempts: 3 });
        socketRef.current = socket;

        socket.on("connect", () => {
          setIsConnected(true);
          simulatingRef.current = false;
          clearInterval(simIntervalRef.current);
          addAlert("info", "Server Connected", `Live data from ${SERVER_URL}`, "SYSTEM");
        });

        socket.on("snapshot", ({ sensors, valves: v, alerts: a }) => {
          const enriched = {};
          ["A","B"].forEach((apt) => {
            enriched[apt] = {};
            ROOMS.forEach((room) => {
              const d = sensors[apt]?.[room] || {};
              enriched[apt][room] = {
                ppm:         d.ppm || 0,
                status:      d.status || "safe",
                history:     Array(20).fill(d.ppm || 0),
                gasType:     d.gasType || "Methane",
                sensorId:    `SEN-${apt}-${room.slice(0,3).toUpperCase()}`,
                lastUpdated: d.lastUpdated ? new Date(d.lastUpdated) : new Date(),
              };
            });
          });
          setReadings(enriched);
          setValves(v);
          setAlerts(a.map((al) => ({ ...al, time: new Date(al.time) })));
        });

        socket.on("sensor_reading", ({ apt, room, ppm }) => updateRoom(apt, room, ppm));
        socket.on("valve_update",   ({ apt, open })      => setValves((prev) => ({ ...prev, [apt]: open })));
        socket.on("alert",          (alert)              => setAlerts((prev) => [{ ...alert, time: new Date(alert.time) }, ...prev.slice(0,29)]));

        socket.on("disconnect", () => {
          setIsConnected(false);
          startSimulation();
          addAlert("warning", "Server Disconnected", "Switched to simulated data", "SYSTEM");
        });
      } catch {
        // socket.io-client not installed — simulation continues
      }
    };

    tryConnect();

    return () => {
      socket?.disconnect();
      clearInterval(simIntervalRef.current);
    };
  }, [addAlert, updateRoom, startSimulation]);

  const cutValve = useCallback((apt) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit("valve_command", { apt, action: "CLOSE" });
    } else {
      setValves((prev) => ({ ...prev, [apt]: false }));
      addAlert("warning", `Valve Cut — Apt ${apt}`, "Manual cut by watchman", apt);
    }
  }, [addAlert]);

  const restoreValve = useCallback((apt) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit("valve_command", { apt, action: "OPEN" });
    } else {
      setValves((prev) => ({ ...prev, [apt]: true }));
      addAlert("info", `Valve Restored — Apt ${apt}`, "Restored by watchman", apt);
    }
  }, [addAlert]);

  const cutAllValves = useCallback(() => {
    if (socketRef.current?.connected) {
      socketRef.current.emit("emergency_shutdown");
    } else {
      setValves({ A: false, B: false });
      addAlert("critical", "EMERGENCY SHUTDOWN", "All valves cut", "ALL");
    }
  }, [addAlert]);

  return {
    readings, valves, alerts, isConnected,
    cutValve, restoreValve, cutAllValves,
    thresholds: THRESHOLDS, rooms: ROOMS,
  };
}
