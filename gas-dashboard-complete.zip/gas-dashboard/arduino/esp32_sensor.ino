/*
 * Gas Leakage Detection — ESP32 / Arduino Firmware
 * 
 * Hardware required:
 *   - ESP32 (or ESP8266) development board
 *   - MQ-2  sensor → Kitchen     (LPG, smoke, propane)
 *   - MQ-5  sensor → Living Room (Natural gas, LPG)
 *   - MQ-9  sensor → Bedroom     (CO, flammable gas)
 *   - MQ-135 sensor → Bathroom   (general air quality)
 *   - Relay module (for gas valve solenoid)
 *   - Active buzzer
 * 
 * Libraries needed (install via Arduino Library Manager):
 *   - PubSubClient  (MQTT)
 *   - WiFi          (built-in for ESP32)
 * 
 * Wiring:
 *   MQ-2  AOUT → GPIO 34
 *   MQ-5  AOUT → GPIO 35
 *   MQ-9  AOUT → GPIO 32
 *   MQ-135 AOUT → GPIO 33
 *   Relay IN   → GPIO 26  (controls solenoid gas valve)
 *   Buzzer     → GPIO 27
 */

#include <WiFi.h>
#include <PubSubClient.h>

// ── CONFIGURATION ─────────────────────────────────────────────────
// Replace with your actual WiFi and broker details
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* MQTT_BROKER   = "192.168.1.100";   // Raspberry Pi IP
const int   MQTT_PORT     = 1883;

// Which apartment is this ESP32 installed in?
const char* APARTMENT = "aptA";   // Change to "aptB" for second unit

// ── PIN DEFINITIONS ───────────────────────────────────────────────
#define SENSOR_KITCHEN      34    // MQ-2
#define SENSOR_LIVING_ROOM  35    // MQ-5
#define SENSOR_BEDROOM      32    // MQ-9
#define SENSOR_BATHROOM     33    // MQ-135
#define RELAY_PIN           26    // Gas valve relay (LOW = cut gas)
#define BUZZER_PIN          27

// ── THRESHOLDS ────────────────────────────────────────────────────
#define PPM_WARNING  300
#define PPM_DANGER   500

// ── MQTT TOPICS ───────────────────────────────────────────────────
// Will publish to: gas/aptA/Kitchen, gas/aptA/Living_Room, etc.
// Will subscribe to: gas/aptA/valve/command

// ── GLOBALS ───────────────────────────────────────────────────────
WiFiClient   espClient;
PubSubClient mqtt(espClient);

bool   valveOpen    = true;
unsigned long lastPublish = 0;
const  long   PUBLISH_INTERVAL = 2000;  // publish every 2 seconds

// ── SENSOR READING ────────────────────────────────────────────────
// Converts raw ADC (0-4095) to approximate PPM
// Calibrate RL_VALUE and Ro for your specific MQ sensor batch
float rawToPPM(int rawValue, float RL_VALUE = 10.0) {
  float voltage = (rawValue / 4095.0) * 3.3;
  if (voltage < 0.01) voltage = 0.01;
  float RS = (3.3 - voltage) / voltage * RL_VALUE;
  float ratio = RS / 10.0;  // Ro calibrated in clean air
  // Simplified LPG curve: log(ppm) = m*log(ratio) + b
  float ppm = pow(10, (-2.2 * log10(ratio) + 2.9));
  return constrain(ppm, 0, 1000);
}

// ── WIFI SETUP ────────────────────────────────────────────────────
void setupWiFi() {
  delay(10);
  Serial.println("Connecting to WiFi...");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connected: " + WiFi.localIP().toString());
  } else {
    Serial.println("\nWiFi failed — running offline");
  }
}

// ── MQTT CALLBACK (receive valve commands) ────────────────────────
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String message = "";
  for (int i = 0; i < length; i++) message += (char)payload[i];

  Serial.println("[MQTT] Received: " + String(topic) + " → " + message);

  String valveTopic = String("gas/") + APARTMENT + "/valve/command";
  if (String(topic) == valveTopic) {
    if (message == "CLOSE") {
      cutGasValve();
    } else if (message == "OPEN") {
      restoreGasValve();
    }
  }
}

// ── MQTT RECONNECT ────────────────────────────────────────────────
void reconnectMQTT() {
  while (!mqtt.connected()) {
    Serial.print("Connecting to MQTT...");
    String clientId = String("ESP32-") + APARTMENT;
    if (mqtt.connect(clientId.c_str())) {
      Serial.println("connected");
      // Subscribe to valve command topic
      String topic = String("gas/") + APARTMENT + "/valve/command";
      mqtt.subscribe(topic.c_str());
      // Publish online status
      mqtt.publish((String("gas/") + APARTMENT + "/status").c_str(), "ONLINE");
    } else {
      Serial.println("failed, retry in 5s");
      delay(5000);
    }
  }
}

// ── VALVE CONTROL ─────────────────────────────────────────────────
void cutGasValve() {
  digitalWrite(RELAY_PIN, LOW);   // Energize relay → close solenoid valve
  valveOpen = false;
  Serial.println("[VALVE] GAS CUT");
  // Alert buzzer: 3 short beeps
  for (int i = 0; i < 3; i++) {
    digitalWrite(BUZZER_PIN, HIGH); delay(200);
    digitalWrite(BUZZER_PIN, LOW);  delay(100);
  }
  // Confirm to server
  String topic = String("gas/") + APARTMENT + "/valve/status";
  mqtt.publish(topic.c_str(), "CLOSED");
}

void restoreGasValve() {
  digitalWrite(RELAY_PIN, HIGH);  // De-energize relay → open solenoid valve
  valveOpen = true;
  Serial.println("[VALVE] GAS RESTORED");
  digitalWrite(BUZZER_PIN, HIGH); delay(500);
  digitalWrite(BUZZER_PIN, LOW);
  String topic = String("gas/") + APARTMENT + "/valve/status";
  mqtt.publish(topic.c_str(), "OPEN");
}

// ── DANGER ALERT (local) ──────────────────────────────────────────
void localAlert(float ppm) {
  if (ppm >= PPM_DANGER) {
    // Continuous alarm
    digitalWrite(BUZZER_PIN, HIGH);
  } else if (ppm >= PPM_WARNING) {
    // Intermittent beep
    digitalWrite(BUZZER_PIN, HIGH); delay(100);
    digitalWrite(BUZZER_PIN, LOW);  delay(400);
  } else {
    digitalWrite(BUZZER_PIN, LOW);
  }
}

// ── PUBLISH SENSOR READING ────────────────────────────────────────
void publishReading(const char* room, int rawValue) {
  float ppm = rawToPPM(rawValue);
  String topic   = String("gas/") + APARTMENT + "/" + room;
  String payload = String((int)ppm);
  mqtt.publish(topic.c_str(), payload.c_str());
  Serial.println("[SENSOR] " + topic + " = " + payload + " ppm");

  // Auto valve cut on critical level (hardware failsafe)
  if (ppm >= PPM_DANGER && valveOpen) {
    Serial.println("[SAFETY] Critical PPM — cutting gas valve");
    cutGasValve();
  }
}

// ── SETUP ─────────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  pinMode(RELAY_PIN,  OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, HIGH);   // Valve open on boot
  digitalWrite(BUZZER_PIN, LOW);

  // Startup beep
  digitalWrite(BUZZER_PIN, HIGH); delay(300); digitalWrite(BUZZER_PIN, LOW);

  setupWiFi();
  mqtt.setServer(MQTT_BROKER, MQTT_PORT);
  mqtt.setCallback(mqttCallback);
}

// ── MAIN LOOP ─────────────────────────────────────────────────────
void loop() {
  // Maintain MQTT connection
  if (!mqtt.connected()) reconnectMQTT();
  mqtt.loop();

  // Publish sensor readings every PUBLISH_INTERVAL ms
  unsigned long now = millis();
  if (now - lastPublish >= PUBLISH_INTERVAL) {
    lastPublish = now;

    int rawKitchen    = analogRead(SENSOR_KITCHEN);
    int rawLiving     = analogRead(SENSOR_LIVING_ROOM);
    int rawBedroom    = analogRead(SENSOR_BEDROOM);
    int rawBathroom   = analogRead(SENSOR_BATHROOM);

    publishReading("Kitchen",      rawKitchen);
    publishReading("Living_Room",  rawLiving);
    publishReading("Bedroom",      rawBedroom);
    publishReading("Bathroom",     rawBathroom);

    // Local alarm based on highest reading
    float maxPPM = max({
      rawToPPM(rawKitchen), rawToPPM(rawLiving),
      rawToPPM(rawBedroom), rawToPPM(rawBathroom)
    });
    localAlert(maxPPM);
  }
}
