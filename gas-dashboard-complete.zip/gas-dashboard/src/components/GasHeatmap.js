// src/components/GasHeatmap.js

import React, { useRef, useEffect } from "react";

const ROOM_LAYOUT = [
  { name: "Kitchen",     x: 0,    y: 0,    w: 0.42, h: 0.48 },
  { name: "Living Room", x: 0.42, y: 0,    w: 0.58, h: 0.48 },
  { name: "Bedroom",     x: 0,    y: 0.48, w: 0.55, h: 0.52 },
  { name: "Bathroom",    x: 0.55, y: 0.48, w: 0.45, h: 0.52 },
];

function ppmToColor(ppm, alpha = 0.85) {
  const t = Math.min(1, ppm / 600);
  let r, g, b;
  if (t < 0.5) {
    const tt = t * 2;
    r = Math.round(34  + (245 - 34)  * tt);
    g = Math.round(197 + (158 - 197) * tt);
    b = Math.round(94  + (11  - 94)  * tt);
  } else {
    const tt = (t - 0.5) * 2;
    r = Math.round(245 + (239 - 245) * tt);
    g = Math.round(158 + (68  - 158) * tt);
    b = Math.round(11  + (44  - 11)  * tt);
  }
  return `rgba(${r},${g},${b},${alpha})`;
}

function drawArrows(ctx, cx, cy, rw, rh, ppm, angle) {
  if (ppm < 30) return;
  const intensity = Math.min(1, ppm / 500);
  ctx.save();
  ctx.strokeStyle = `rgba(255,255,255,${0.15 + intensity * 0.45})`;
  ctx.lineWidth = 1.2;
  ctx.setLineDash([4, 5]);

  const count = Math.floor(2 + intensity * 3);
  for (let i = 0; i < count; i++) {
    const offset = ((i - count / 2) * 18);
    const startX = cx + Math.cos(angle + Math.PI / 2) * offset;
    const startY = cy + Math.sin(angle + Math.PI / 2) * offset;
    const len = 20 + intensity * 18;
    const ex = startX + Math.cos(angle) * len;
    const ey = startY + Math.sin(angle) * len;

    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(ex, ey);

    // arrowhead
    const headLen = 6;
    ctx.moveTo(ex, ey);
    ctx.lineTo(ex - headLen * Math.cos(angle - 0.4), ey - headLen * Math.sin(angle - 0.4));
    ctx.moveTo(ex, ey);
    ctx.lineTo(ex - headLen * Math.cos(angle + 0.4), ey - headLen * Math.sin(angle + 0.4));
    ctx.stroke();
  }
  ctx.setLineDash([]);
  ctx.restore();
}

export default function GasHeatmap({ readings, aptLabel, tickRef }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = canvas.width;
    const H = canvas.height;

    ctx.clearRect(0, 0, W, H);

    // Dark base
    ctx.fillStyle = "#0d1117";
    ctx.beginPath();
    ctx.roundRect(0, 0, W, H, 10);
    ctx.fill();

    ROOM_LAYOUT.forEach((room) => {
      const data = readings[room.name];
      if (!data) return;
      const ppm = data.ppm;
      const rx = room.x * W;
      const ry = room.y * H;
      const rw = room.w * W;
      const rh = room.h * H;
      const cx = rx + rw / 2;
      const cy = ry + rh / 2;
      const pad = 4;

      // Room bg
      ctx.fillStyle = "#161b26";
      ctx.strokeStyle = "rgba(255,255,255,0.09)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(rx + pad, ry + pad, rw - pad * 2, rh - pad * 2, 8);
      ctx.fill();
      ctx.stroke();

      // Heatmap gradient
      const r = Math.max(rw, rh) * 0.7;
      const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
      grad.addColorStop(0,   ppmToColor(ppm, 0.88));
      grad.addColorStop(0.5, ppmToColor(ppm, 0.40));
      grad.addColorStop(1,   ppmToColor(ppm, 0.00));
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.roundRect(rx + pad, ry + pad, rw - pad * 2, rh - pad * 2, 8);
      ctx.fill();

      // Danger pulse ring
      if (ppm >= 500) {
        ctx.strokeStyle = `rgba(239,68,68,${0.4 + 0.3 * Math.sin(Date.now() / 300)})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.roundRect(rx + pad + 2, ry + pad + 2, rw - pad * 2 - 4, rh - pad * 2 - 4, 8);
        ctx.stroke();
      }

      // Gas flow arrows
      const flowAngle = (ppm * 0.013 + room.x * 2 + room.y) % (Math.PI * 2);
      drawArrows(ctx, cx, cy, rw, rh, ppm, flowAngle);

      // Room name
      ctx.fillStyle = "rgba(255,255,255,0.55)";
      ctx.font = "bold 11px 'Courier New', monospace";
      ctx.textAlign = "center";
      ctx.fillText(room.name.toUpperCase(), cx, ry + pad + 18);

      // PPM value
      ctx.fillStyle = ppmToColor(ppm, 1);
      ctx.font = `bold ${Math.min(26, rw * 0.18)}px 'Courier New', monospace`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(`${ppm}`, cx, cy - 6);

      // unit
      ctx.fillStyle = "rgba(255,255,255,0.45)";
      ctx.font = "10px 'Courier New', monospace";
      ctx.fillText("ppm", cx, cy + 14);

      // Status tag
      const statusColors = { safe: "#22c55e", warning: "#f59e0b", danger: "#ef4444" };
      ctx.fillStyle = statusColors[data.status] || "#22c55e";
      ctx.font = "bold 9px 'Courier New', monospace";
      ctx.fillText(data.status.toUpperCase(), cx, ry + rh - pad - 8);

      ctx.textBaseline = "alphabetic";
    });
  });

  return (
    <div style={{ position: "relative" }}>
      <canvas
        ref={canvasRef}
        width={560}
        height={300}
        style={{
          width: "100%",
          borderRadius: 10,
          display: "block",
          border: "1px solid rgba(255,255,255,0.06)",
        }}
      />
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        marginTop: 10, fontSize: 11, color: "#555d72"
      }}>
        <span>Low</span>
        <div style={{
          height: 6, flex: 1,
          background: "linear-gradient(to right, #22c55e, #f59e0b, #ef4444)",
          borderRadius: 3
        }} />
        <span>Critical</span>
        <span style={{ marginLeft: "auto", fontSize: 10 }}>
          ↗ arrows = flow direction
        </span>
      </div>
    </div>
  );
}
