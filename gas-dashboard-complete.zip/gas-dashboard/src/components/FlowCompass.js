// src/components/FlowCompass.js

import React from "react";

const DIR_NAMES = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];

function getFlowSpeed(ppm) {
  if (ppm < 30)  return "No flow";
  if (ppm < 150) return "Low";
  if (ppm < 350) return "Moderate";
  return "High";
}

function getColor(ppm) {
  if (ppm >= 500) return "#ef4444";
  if (ppm >= 300) return "#f59e0b";
  return "#22c55e";
}

function CompassDial({ label, ppm, angle }) {
  const color = getColor(ppm);
  const speed = getFlowSpeed(ppm);
  const dirIdx = Math.round(((angle % 360) + 360) % 360 / 45) % 8;

  return (
    <div style={{
      background: "#161b26",
      border: "1px solid rgba(255,255,255,0.07)",
      borderRadius: 10,
      padding: "10px 8px",
      textAlign: "center",
      minWidth: 0,
    }}>
      <div style={{ fontSize: 10, color: "#555d72", marginBottom: 6, fontFamily: "'Courier New', monospace" }}>
        {label}
      </div>
      <svg
        width="76"
        height="76"
        viewBox="0 0 76 76"
        style={{ display: "block", margin: "0 auto" }}
      >
        {/* Outer ring */}
        <circle cx="38" cy="38" r="34" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="1" />
        <circle cx="38" cy="38" r="26" fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="1" />

        {/* Cardinal labels */}
        {DIR_NAMES.map((name, i) => {
          const rad = (i * 45 - 90) * (Math.PI / 180);
          const x = 38 + 30 * Math.cos(rad);
          const y = 38 + 30 * Math.sin(rad);
          return (
            <text
              key={name}
              x={x} y={y}
              fill="rgba(255,255,255,0.22)"
              fontSize="6"
              textAnchor="middle"
              dominantBaseline="central"
              fontFamily="'Courier New', monospace"
              fontWeight={i % 2 === 0 ? "700" : "400"}
            >
              {name}
            </text>
          );
        })}

        {/* Needle */}
        <g transform={`rotate(${angle}, 38, 38)`}>
          {/* North pointer (active) */}
          <polygon
            points="38,8 34,36 38,32 42,36"
            fill={ppm < 30 ? "rgba(255,255,255,0.15)" : color}
            opacity={ppm < 30 ? 0.4 : 0.95}
          />
          {/* South pointer */}
          <polygon
            points="38,68 34,40 38,44 42,40"
            fill="rgba(255,255,255,0.12)"
          />
        </g>

        {/* Center dot */}
        <circle cx="38" cy="38" r="4" fill={ppm < 30 ? "#333" : color} />
        <circle cx="38" cy="38" r="2" fill="#0d1117" />
      </svg>

      <div style={{ fontSize: 11, fontWeight: 700, color, marginTop: 6, fontFamily: "'Courier New', monospace" }}>
        {DIR_NAMES[dirIdx]} · {speed}
      </div>
      <div style={{ fontSize: 10, color: "#555d72" }}>{ppm} ppm</div>
    </div>
  );
}

export default function FlowCompass({ readings, rooms }) {
  const allRooms = [
    ...rooms.map((r) => ({ label: `A · ${r}`, ppm: readings.A[r]?.ppm || 0, key: `A-${r}` })),
    ...rooms.map((r) => ({ label: `B · ${r}`, ppm: readings.B[r]?.ppm || 0, key: `B-${r}` })),
  ];

  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "repeat(4, 1fr)",
      gap: 8,
    }}>
      {allRooms.map(({ label, ppm, key }, i) => {
        // Derive a pseudo-angle from ppm and room index
        const angle = ((ppm * 1.37 + i * 43) % 360 + 360) % 360;
        return (
          <CompassDial key={key} label={label} ppm={ppm} angle={angle} />
        );
      })}
    </div>
  );
}
